"use client"

import { useEffect, useRef, useState, useCallback } from "react"

interface ThreatZone {
  id: string
  lat: number
  lon: number
  r: number
  level: number
  name: string
  country: string
  incidents: number
  status: string
  category: string
  summary?: string
  updates?: { text: string; time: string }[]
  _sx?: number
  _sy?: number
  _sr?: number
  _vis?: boolean
}

const threatZones: ThreatZone[] = [
  { id: "gz", lat: 31.5, lon: 34.5, r: 0.16, level: 0.96, name: "ISRAEL-GAZA CONFLICT ZONE", country: "Israel / Palestine", incidents: 280, status: "CRITICAL", category: "ARMED CONFLICT" },
  { id: "ua", lat: 49.0, lon: 32.0, r: 0.2, level: 0.92, name: "UKRAINE WAR ZONE", country: "Ukraine", incidents: 310, status: "CRITICAL", category: "INTERSTATE WAR" },
  { id: "sd", lat: 15.5, lon: 32.5, r: 0.18, level: 0.88, name: "SUDAN CIVIL WAR", country: "Sudan", incidents: 195, status: "CRITICAL", category: "CIVIL WAR" },
  { id: "ym", lat: 15.3, lon: 44.2, r: 0.17, level: 0.87, name: "YEMEN CONFLICT", country: "Yemen", incidents: 170, status: "CRITICAL", category: "ARMED CONFLICT" },
  { id: "sh", lat: 14.0, lon: 2.0, r: 0.22, level: 0.85, name: "SAHEL INSURGENCY BELT", country: "Mali / Niger / Burkina Faso", incidents: 145, status: "CRITICAL", category: "INSURGENCY" },
  { id: "ca", lat: 6.5, lon: 21.0, r: 0.2, level: 0.82, name: "CENTRAL AFRICA INSTABILITY", country: "DRC / CAR", incidents: 130, status: "HIGH", category: "ARMED CONFLICT" },
  { id: "sy", lat: 33.5, lon: 36.3, r: 0.16, level: 0.83, name: "SYRIA ONGOING CONFLICT", country: "Syria", incidents: 105, status: "HIGH", category: "CIVIL WAR" },
  { id: "af", lat: 34.5, lon: 69.2, r: 0.17, level: 0.81, name: "AFGHANISTAN SECURITY CRISIS", country: "Afghanistan", incidents: 120, status: "HIGH", category: "GOVERNANCE COLLAPSE" },
  { id: "iq", lat: 33.3, lon: 44.4, r: 0.15, level: 0.79, name: "IRAQ SECURITY SITUATION", country: "Iraq", incidents: 88, status: "HIGH", category: "TERRORISM" },
  { id: "et", lat: 9.0, lon: 38.7, r: 0.16, level: 0.79, name: "ETHIOPIA INTERNAL CONFLICT", country: "Ethiopia", incidents: 90, status: "HIGH", category: "CIVIL CONFLICT" },
  { id: "mm", lat: 24.0, lon: 96.0, r: 0.15, level: 0.78, name: "MYANMAR CIVIL WAR", country: "Myanmar", incidents: 115, status: "HIGH", category: "CIVIL WAR" },
  { id: "kp", lat: 38.9, lon: 125.7, r: 0.13, level: 0.75, name: "KOREAN PENINSULA TENSION", country: "North / South Korea", incidents: 22, status: "HIGH", category: "GEOPOLITICAL" },
  { id: "tw", lat: 23.5, lon: 121.0, r: 0.13, level: 0.73, name: "TAIWAN STRAIT TENSION", country: "Taiwan / China", incidents: 18, status: "HIGH", category: "GEOPOLITICAL" },
  { id: "ng", lat: 5.0, lon: 7.5, r: 0.15, level: 0.7, name: "NIGER DELTA INSTABILITY", country: "Nigeria", incidents: 58, status: "HIGH", category: "INSURGENCY" },
  { id: "cc", lat: 43.5, lon: 41.0, r: 0.13, level: 0.68, name: "SOUTH CAUCASUS TENSIONS", country: "Armenia / Azerbaijan", incidents: 35, status: "HIGH", category: "TERRITORIAL" },
  { id: "ru", lat: 60.0, lon: 28.0, r: 0.14, level: 0.65, name: "RUSSIA-NATO FRONTIER TENSION", country: "Finland / Baltic States", incidents: 14, status: "ELEVATED", category: "GEOPOLITICAL" },
  { id: "hoa", lat: 11.5, lon: 43.1, r: 0.13, level: 0.67, name: "HORN OF AFRICA TENSIONS", country: "Ethiopia / Eritrea / Somalia", incidents: 45, status: "ELEVATED", category: "REGIONAL TENSION" },
  { id: "ip", lat: 28.6, lon: 77.2, r: 0.13, level: 0.52, name: "INDIA-PAKISTAN LOC TENSION", country: "India / Pakistan", incidents: 28, status: "ELEVATED", category: "GEOPOLITICAL" },
  { id: "pg", lat: 25.0, lon: 55.0, r: 0.12, level: 0.5, name: "GULF MARITIME TENSIONS", country: "Persian Gulf", incidents: 16, status: "ELEVATED", category: "MARITIME" },
  { id: "ea", lat: -0.5, lon: 37.0, r: 0.12, level: 0.48, name: "EAST AFRICA RIFT TENSIONS", country: "Kenya / Somalia", incidents: 30, status: "ELEVATED", category: "TERRORISM" },
  { id: "vg", lat: 3.8, lon: -59.0, r: 0.11, level: 0.42, name: "VENEZUELA-GUYANA DISPUTE", country: "Venezuela / Guyana", incidents: 8, status: "MONITORED", category: "TERRITORIAL" },
  { id: "sa", lat: -15.0, lon: 30.0, r: 0.12, level: 0.38, name: "SOUTHERN AFRICA UNREST", country: "Mozambique / Zambia", incidents: 20, status: "MONITORED", category: "INSURGENCY" },
  { id: "cas", lat: 52.0, lon: 60.0, r: 0.11, level: 0.35, name: "CENTRAL ASIAN INSTABILITY", country: "Kazakhstan / Kyrgyzstan", incidents: 10, status: "MONITORED", category: "POLITICAL" },
  { id: "med", lat: 37.0, lon: 15.0, r: 0.1, level: 0.28, name: "CENTRAL MED MIGRATION CRISIS", country: "Mediterranean Sea", incidents: 6, status: "STABLE", category: "HUMANITARIAN" },
]

interface GeoRings {
  rings: [number, number][][]
}

export default function ThreatGlobe() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [utcTime, setUtcTime] = useState("--:--:--")
  const [hoveredZone, setHoveredZone] = useState<ThreatZone | null>(null)
  const [selectedZone, setSelectedZone] = useState<ThreatZone | null>(null)
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 })
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalIntel, setModalIntel] = useState<{ summary: string; events: { text: string; time: string }[]; drivers: string[]; outlook: string; articles: { title: string; source: string; url: string; time: string }[] } | null>(null)
  const [isLoadingIntel, setIsLoadingIntel] = useState(false)

  const stateRef = useRef({
    rotX: 0.3,
    rotY: -0.5,
    isDragging: false,
    dragMoved: false,
    lastMX: 0,
    lastMY: 0,
    velX: 0,
    velY: 0,
    zoomScale: 1.0,
    time: 0,
    geoFeatures: [] as GeoRings[],
    geoLoaded: false,
    W: 0,
    H: 0,
    R: 0,
    zones: threatZones.map((z) => ({ ...z })),
  })

  // Load GeoJSON
  useEffect(() => {
    async function loadGeo() {
      try {
        const res = await fetch("https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json")
        const topo = await res.json()
        const { arcs, transform, objects } = topo
        const { scale, translate } = transform
        const land = objects.countries

        function decodeArc(i: number): [number, number][] {
          const rev = i < 0
          const idx = rev ? ~i : i
          let x = 0,
            y = 0
          const pts: [number, number][] = arcs[idx].map(([dx, dy]: [number, number]) => {
            x += dx
            y += dy
            return [x * scale[0] + translate[0], y * scale[1] + translate[1]] as [number, number]
          })
          return rev ? pts.reverse() : pts
        }

        function toRings(g: { type: string; arcs: number[][] | number[][][] }): [number, number][][] {
          if (!g) return []
          if (g.type === "Polygon") return (g.arcs as number[][]).map((r) => r.flatMap(decodeArc))
          if (g.type === "MultiPolygon") return (g.arcs as number[][][]).flatMap((p) => p.map((r) => r.flatMap(decodeArc)))
          return []
        }

        stateRef.current.geoFeatures = land.geometries.map((g: { type: string; arcs: number[][] | number[][][] }) => ({ rings: toRings(g) })).filter((r: GeoRings) => r.rings.length)
        stateRef.current.geoLoaded = true
      } catch (e) {
        console.warn("GeoJSON load failed", e)
      }
    }
    loadGeo()
  }, [])

  // Clock
  useEffect(() => {
    const interval = setInterval(() => {
      const n = new Date()
      setUtcTime(`${String(n.getUTCHours()).padStart(2, "0")}:${String(n.getUTCMinutes()).padStart(2, "0")}:${String(n.getUTCSeconds()).padStart(2, "0")}`)
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  const getThreatColor = useCallback((lv: number) => {
    if (lv > 0.85) return { r: 255, g: 20, b: 60 }
    if (lv > 0.65) return { r: 255, g: 130, b: 0 }
    if (lv > 0.45) return { r: 255, g: 210, b: 0 }
    if (lv > 0.28) return { r: 0, g: 255, b: 180 }
    return { r: 20, g: 120, b: 90 }
  }, [])

  const rgba = useCallback((c: { r: number; g: number; b: number }, a: number) => {
    return `rgba(${c.r},${c.g},${c.b},${a})`
  }, [])

  // Canvas rendering
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const state = stateRef.current

    function resize() {
      state.W = canvas!.width = window.innerWidth
      state.H = canvas!.height = window.innerHeight
      state.R = Math.min(state.W, state.H) * 0.36
    }
    resize()
    window.addEventListener("resize", resize)

    const stars = Array.from({ length: 180 }, () => ({
      x: Math.random() * 2 - 1,
      y: Math.random() * 2 - 1,
      s: Math.random() * 1.3 + 0.3,
      a: Math.random() * 0.55 + 0.1,
    }))

    function ll3d(lat: number, lon: number) {
      const phi = ((90 - lat) * Math.PI) / 180
      const theta = ((lon + 180) * Math.PI) / 180
      return {
        x: -Math.sin(phi) * Math.cos(theta),
        y: Math.cos(phi),
        z: Math.sin(phi) * Math.sin(theta),
      }
    }

    function rot(p: { x: number; y: number; z: number }) {
      const x1 = p.x * Math.cos(state.rotY) + p.z * Math.sin(state.rotY)
      const z1 = -p.x * Math.sin(state.rotY) + p.z * Math.cos(state.rotY)
      return {
        x: x1,
        y: p.y * Math.cos(state.rotX) - z1 * Math.sin(state.rotX),
        z: p.y * Math.sin(state.rotX) + z1 * Math.cos(state.rotX),
      }
    }

    function proj(p: { x: number; y: number; z: number }) {
      const rz = state.R * state.zoomScale
      return { x: state.W / 2 + p.x * rz, y: state.H / 2 - p.y * rz }
    }

    function drawGrid() {
      ctx!.strokeStyle = "rgba(0,255,180,0.055)"
      ctx!.lineWidth = 0.5
      for (let lat = -80; lat <= 80; lat += 20) {
        ctx!.beginPath()
        let f = true
        for (let lon = -180; lon <= 180; lon += 3) {
          const r = rot(ll3d(lat, lon))
          if (r.z < 0) {
            f = true
            continue
          }
          const s = proj(r)
          if (f) {
            ctx!.moveTo(s.x, s.y)
            f = false
          } else ctx!.lineTo(s.x, s.y)
        }
        ctx!.stroke()
      }
      for (let lon = -180; lon < 180; lon += 30) {
        ctx!.beginPath()
        let f = true
        for (let lat = -90; lat <= 90; lat += 3) {
          const r = rot(ll3d(lat, lon))
          if (r.z < 0) {
            f = true
            continue
          }
          const s = proj(r)
          if (f) {
            ctx!.moveTo(s.x, s.y)
            f = false
          } else ctx!.lineTo(s.x, s.y)
        }
        ctx!.stroke()
      }
    }

    function drawContinents() {
      if (!state.geoLoaded) return
      for (const { rings } of state.geoFeatures) {
        for (const ring of rings) {
          ctx!.beginPath()
          let pd = false
          for (const [lon, lat] of ring) {
            const r = rot(ll3d(lat, lon))
            if (r.z < 0) {
              pd = false
              continue
            }
            const s = proj(r)
            if (!pd) {
              ctx!.moveTo(s.x, s.y)
              pd = true
            } else ctx!.lineTo(s.x, s.y)
          }
          // Fill countries
          ctx!.fillStyle = "rgba(0,180,120,0.12)"
          ctx!.fill()
          // Draw borders clearly
          ctx!.strokeStyle = "rgba(0,255,180,0.65)"
          ctx!.lineWidth = 0.8
          ctx!.stroke()
        }
      }
    }

    function drawZone(z: ThreatZone) {
      const rc = rot(ll3d(z.lat, z.lon))
      if (rc.z < 0.05) return
      const sp = proj(rc)
      const sr = z.r * state.R * state.zoomScale * (0.6 + rc.z * 0.4)
      const c = getThreatColor(z.level)
      const pulse = 0.5 + 0.5 * Math.sin(state.time * 2 + z.lon * 0.1)
      const hov = hoveredZone?.id === z.id
      const sel = selectedZone?.id === z.id

      if (z.level > 0.5) {
        for (let i = 3; i >= 1; i--) {
          ctx!.beginPath()
          ctx!.arc(sp.x, sp.y, sr * (1 + i * 0.28 + (hov ? 0.18 : 0)), 0, Math.PI * 2)
          ctx!.strokeStyle = rgba(c, (0.07 / i) * z.level * (hov ? 1.6 : 1))
          ctx!.lineWidth = 1
          ctx!.stroke()
        }
      }

      const g = ctx!.createRadialGradient(sp.x, sp.y, 0, sp.x, sp.y, sr)
      g.addColorStop(0, rgba(c, 0.44 + pulse * 0.1 * z.level))
      g.addColorStop(0.5, rgba(c, 0.17 * z.level))
      g.addColorStop(1, rgba(c, 0))
      ctx!.beginPath()
      ctx!.arc(sp.x, sp.y, sr, 0, Math.PI * 2)
      ctx!.fillStyle = g
      ctx!.fill()

      if (sel) {
        ctx!.beginPath()
        ctx!.arc(sp.x, sp.y, sr * 0.38, 0, Math.PI * 2)
        ctx!.strokeStyle = rgba(c, 0.9)
        ctx!.lineWidth = 1.5
        ctx!.stroke()
      }

      const dr = hov || sel ? 5.5 : z.level * 3 + 1.5
      ctx!.beginPath()
      ctx!.arc(sp.x, sp.y, dr, 0, Math.PI * 2)
      ctx!.fillStyle = rgba(c, 0.96)
      ctx!.shadowBlur = hov ? 18 : 10
      ctx!.shadowColor = rgba(c, 1)
      ctx!.fill()
      ctx!.shadowBlur = 0

      z._sx = sp.x
      z._sy = sp.y
      z._sr = sr
      z._vis = true
    }

    function draw() {
      const Rz = state.R * state.zoomScale
      ctx!.clearRect(0, 0, state.W, state.H)

      // Background
      const bg = ctx!.createRadialGradient(state.W / 2, state.H / 2, 0, state.W / 2, state.H / 2, Math.max(state.W, state.H) * 0.7)
      bg.addColorStop(0, "#030d0a")
      bg.addColorStop(1, "#020408")
      ctx!.fillStyle = bg
      ctx!.fillRect(0, 0, state.W, state.H)

      // Stars
      stars.forEach((s) => {
        const sp = { x: state.W / 2 + s.x * state.W * 0.6, y: state.H / 2 + s.y * state.H * 0.6 }
        if (sp.x < 0 || sp.x > state.W || sp.y < 0 || sp.y > state.H) return
        ctx!.beginPath()
        ctx!.arc(sp.x, sp.y, s.s * 0.44, 0, Math.PI * 2)
        ctx!.fillStyle = `rgba(200,255,240,${s.a * (0.6 + 0.4 * Math.sin(state.time + s.x * 10))})`
        ctx!.fill()
      })

      // Globe shadow
      const sg = ctx!.createRadialGradient(state.W / 2 + Rz * 0.18, state.H / 2 + Rz * 0.18, 0, state.W / 2, state.H / 2, Rz * 1.1)
      sg.addColorStop(0, "rgba(0,0,0,0)")
      sg.addColorStop(0.8, "rgba(0,0,0,0)")
      sg.addColorStop(1, "rgba(0,0,0,0.45)")
      ctx!.beginPath()
      ctx!.arc(state.W / 2, state.H / 2, Rz * 1.1, 0, Math.PI * 2)
      ctx!.fillStyle = sg
      ctx!.fill()

      // Globe base
      const gg = ctx!.createRadialGradient(state.W / 2 - Rz * 0.25, state.H / 2 - Rz * 0.25, 0, state.W / 2, state.H / 2, Rz)
      gg.addColorStop(0, "#0a2a20")
      gg.addColorStop(0.5, "#061a12")
      gg.addColorStop(1, "#020c08")
      ctx!.beginPath()
      ctx!.arc(state.W / 2, state.H / 2, Rz, 0, Math.PI * 2)
      ctx!.fillStyle = gg
      ctx!.fill()

      // Globe border
      ctx!.beginPath()
      ctx!.arc(state.W / 2, state.H / 2, Rz, 0, Math.PI * 2)
      ctx!.strokeStyle = "rgba(0,255,180,0.14)"
      ctx!.lineWidth = 1
      ctx!.stroke()

      // Atmosphere glow
      const ag = ctx!.createRadialGradient(state.W / 2, state.H / 2, Rz * 0.9, state.W / 2, state.H / 2, Rz * 1.15)
      ag.addColorStop(0, "rgba(0,255,180,0.07)")
      ag.addColorStop(1, "rgba(0,255,180,0)")
      ctx!.beginPath()
      ctx!.arc(state.W / 2, state.H / 2, Rz * 1.15, 0, Math.PI * 2)
      ctx!.fillStyle = ag
      ctx!.fill()

      // Clip to globe
      ctx!.save()
      ctx!.beginPath()
      ctx!.arc(state.W / 2, state.H / 2, Rz, 0, Math.PI * 2)
      ctx!.clip()

      drawGrid()
      drawContinents()

      // Draw zones sorted by depth
      state.zones.forEach((z) => (z._vis = false))
      ;[...state.zones].sort((a, b) => rot(ll3d(a.lat, a.lon)).z - rot(ll3d(b.lat, b.lon)).z).forEach(drawZone)

      // Specular highlight
      const spec = ctx!.createRadialGradient(state.W / 2 - Rz * 0.4, state.H / 2 - Rz * 0.35, 0, state.W / 2 - Rz * 0.1, state.H / 2 - Rz * 0.1, Rz * 0.8)
      spec.addColorStop(0, "rgba(0,255,180,0.05)")
      spec.addColorStop(0.4, "rgba(0,255,180,0.015)")
      spec.addColorStop(1, "rgba(0,0,0,0)")
      ctx!.fillStyle = spec
      ctx!.fillRect(state.W / 2 - Rz, state.H / 2 - Rz, Rz * 2, Rz * 2)
      ctx!.restore()

      state.time += 0.016
    }

    let animId: number

    function animate() {
      if (!state.isDragging) {
        state.rotY += state.velY
        state.rotX += state.velX
        state.velY *= 0.92
        state.velX *= 0.92
        if (Math.abs(state.velY) < 0.0001) state.velY = 0
        if (Math.abs(state.velX) < 0.0001) state.velX = 0
        state.rotX = Math.max(-1.4, Math.min(1.4, state.rotX))
      }
      draw()
      animId = requestAnimationFrame(animate)
    }
    animate()

    // Mouse events
    const handleMouseDown = (e: MouseEvent) => {
      state.isDragging = true
      state.dragMoved = false
      state.lastMX = e.clientX
      state.lastMY = e.clientY
      state.velX = 0
      state.velY = 0
    }

    const handleMouseMove = (e: MouseEvent) => {
      if (state.isDragging) {
        const dx = e.clientX - state.lastMX
        const dy = e.clientY - state.lastMY
        if (Math.abs(dx) > 2 || Math.abs(dy) > 2) state.dragMoved = true
        state.velY = dx * 0.005
        state.velX = dy * 0.005
        state.rotY += dx * 0.005
        state.rotX += dy * 0.005
        state.rotX = Math.max(-1.4, Math.min(1.4, state.rotX))
        state.lastMX = e.clientX
        state.lastMY = e.clientY
      }

      const mx = e.clientX,
        my = e.clientY
      let found: ThreatZone | null = null
      state.zones.forEach((z) => {
        if (!z._vis) return
        const d = Math.sqrt((mx - (z._sx || 0)) ** 2 + (my - (z._sy || 0)) ** 2)
        if (d < Math.max((z._sr || 0) * 1.1, 14)) {
          if (!found || z.level > found.level) found = z
        }
      })
      setHoveredZone(found)
      setTooltipPos({ x: mx + 15, y: my - 8 })
    }

    const handleMouseUp = () => {
      if (!state.dragMoved && hoveredZone) {
        setSelectedZone(hoveredZone)
        setIsModalOpen(true)
      }
      state.isDragging = false
    }

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault()
      state.zoomScale = Math.max(0.35, Math.min(6.0, state.zoomScale * (e.deltaY < 0 ? 1.08 : 0.925)))
    }

    canvas.addEventListener("mousedown", handleMouseDown)
    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("mouseup", handleMouseUp)
    canvas.addEventListener("wheel", handleWheel, { passive: false })

    return () => {
      cancelAnimationFrame(animId)
      window.removeEventListener("resize", resize)
      canvas.removeEventListener("mousedown", handleMouseDown)
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("mouseup", handleMouseUp)
      canvas.removeEventListener("wheel", handleWheel)
    }
  }, [hoveredZone, selectedZone, getThreatColor, rgba])

  // Load intel for modal
  useEffect(() => {
    if (isModalOpen && selectedZone && !modalIntel) {
      setIsLoadingIntel(true)
      // Simulate intel loading with realistic data
      const timeout = setTimeout(() => {
        setModalIntel({
          summary: `Active conflict zone in ${selectedZone.country}. Current threat level assessed as ${selectedZone.status} with ${selectedZone.incidents} recorded incidents in the past 30 days. Situation remains volatile with ongoing military operations and humanitarian concerns.`,
          events: [
            { text: "Military operations reported in contested areas", time: "2h ago" },
            { text: "Humanitarian corridor negotiations underway", time: "5h ago" },
            { text: "International observers report escalation of hostilities", time: "8h ago" },
            { text: "Civilian displacement continues in affected regions", time: "12h ago" },
            { text: "Diplomatic efforts ongoing between parties", time: "1d ago" },
          ],
          drivers: ["Military Operations", "Political Instability", "Humanitarian Crisis", "Regional Tensions"],
          outlook: "Near-term forecast indicates continued instability with potential for escalation. International monitoring ongoing.",
          articles: [
            { title: `Latest developments in ${selectedZone.name.toLowerCase()}`, source: "Reuters", url: `https://www.reuters.com/world/`, time: "2h ago" },
            { title: `Security analysis: ${selectedZone.country} situation update`, source: "AP News", url: `https://apnews.com/hub/world-news`, time: "5h ago" },
            { title: `International response to ${selectedZone.category.toLowerCase()}`, source: "BBC World", url: `https://www.bbc.com/news/world`, time: "8h ago" },
            { title: `Humanitarian impact in ${selectedZone.country}`, source: "Al Jazeera", url: `https://www.aljazeera.com/`, time: "12h ago" },
          ],
        })
        setIsLoadingIntel(false)
      }, 1500)
      return () => clearTimeout(timeout)
    }
  }, [isModalOpen, selectedZone, modalIntel])

  const closeModal = () => {
    setIsModalOpen(false)
    setSelectedZone(null)
    setModalIntel(null)
  }

  const getStatusColor = (level: number) => {
    if (level > 0.85) return "#ff2244"
    if (level > 0.65) return "#ff8800"
    if (level > 0.45) return "#ffdd00"
    if (level > 0.28) return "#00ffb4"
    return "#1a6655"
  }

  const activeZones = threatZones.filter((z) => z.level > 0.6).length

  const tickerText = threatZones
    .filter((z) => z.level > 0.65)
    .map((z) => `⬥ ${z.status}: ${z.name} — ${z.incidents} events`)
    .join("   ·   ")

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#020408] font-mono text-[#c8fff0]" style={{ cursor: "crosshair" }}>
      {/* Scanlines overlay */}
      <div className="pointer-events-none fixed inset-0 z-[200] bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,0,0,0.07)_2px,rgba(0,0,0,0.07)_4px)]" />
      {/* Vignette */}
      <div className="pointer-events-none fixed inset-0 z-[199] bg-[radial-gradient(ellipse_at_center,transparent_50%,rgba(0,0,0,0.65)_100%)]" />

      {/* Corner decorations */}
      <div className="fixed left-0 top-0 z-[100] h-9 w-9 border-l-2 border-t-2 border-[#00ffb4] opacity-25" />
      <div className="fixed right-0 top-0 z-[100] h-9 w-9 border-r-2 border-t-2 border-[#00ffb4] opacity-25" />
      <div className="fixed bottom-0 left-0 z-[100] h-9 w-9 border-b-2 border-l-2 border-[#00ffb4] opacity-25" />
      <div className="fixed bottom-0 right-0 z-[100] h-9 w-9 border-b-2 border-r-2 border-[#00ffb4] opacity-25" />

      {/* Header */}
      <header className="fixed left-0 right-0 top-0 z-[100] flex items-center justify-between border-b border-[rgba(0,255,180,0.15)] bg-gradient-to-b from-[rgba(0,10,8,0.97)] to-transparent px-6 py-3.5">
        <div className="flex items-center gap-4">
          <h1 className="font-sans text-xl font-black tracking-[0.3em] text-[#00ffb4] drop-shadow-[0_0_20px_rgba(0,255,180,0.6)]">
            THREAT<span className="text-[#ff2244] drop-shadow-[0_0_20px_rgba(255,34,68,0.8)]">WATCH</span>
          </h1>
          <span className="text-[0.5rem] tracking-[0.3em] opacity-40">GLOBAL INTELLIGENCE</span>
        </div>
        <div className="flex items-center gap-6 text-[0.6rem] tracking-[0.12em]">
          <div className="flex flex-col items-end gap-0.5">
            <span className="text-[0.5rem] tracking-[0.15em] opacity-40">FEED</span>
            <span className="flex items-center text-[#00ffb4]">
              <span className="mr-1.5 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-[#00ffb4] shadow-[0_0_8px_#00ffb4]" />
              LIVE
            </span>
          </div>
          <div className="flex flex-col items-end gap-0.5">
            <span className="text-[0.5rem] tracking-[0.15em] opacity-40">ACTIVE ZONES</span>
            <span className="text-[#00ffb4]">{activeZones}</span>
          </div>
          <div className="flex flex-col items-end gap-0.5">
            <span className="text-[0.5rem] tracking-[0.15em] opacity-40">UTC</span>
            <span className="text-[#00ffb4]">{utcTime}</span>
          </div>
        </div>
      </header>

      {/* Canvas */}
      <canvas ref={canvasRef} className="fixed inset-0 block" />

      {/* Left Panel - Conflict List */}
      <div className="fixed bottom-0 left-0 top-14 z-50 w-72 overflow-y-auto border-r border-[#0d2433] bg-[rgba(6,13,18,0.92)] p-4 backdrop-blur-sm">
        <div className="mb-3 border-b border-[#0d2433] pb-2 font-sans text-xs tracking-[0.3em] text-[#3a5565]">// CONFLICT INDEX</div>
        <div className="space-y-2">
          {[...threatZones]
            .sort((a, b) => b.level - a.level)
            .map((z) => (
              <button
                key={z.id}
                onClick={() => {
                  setSelectedZone(z)
                  setIsModalOpen(true)
                }}
                className="group w-full rounded-sm border border-[#0d2433] bg-[rgba(13,36,51,0.5)] p-2.5 text-left transition-all hover:translate-x-0.5 hover:border-l-[#00ffe7] hover:bg-[rgba(13,36,51,0.9)]"
                style={{ borderLeftWidth: "3px", borderLeftColor: getStatusColor(z.level) }}
              >
                <div className="mb-1 text-xs font-semibold tracking-wider text-[#e0f0f8]">{z.name}</div>
                <div className="mb-1.5 text-[0.6rem] text-[#3a5565]">
                  {z.country} · {z.category}
                </div>
                <div className="flex items-center justify-between">
                  <span
                    className="rounded-sm px-1.5 py-0.5 text-[0.5rem] tracking-[0.15em]"
                    style={{
                      backgroundColor: `${getStatusColor(z.level)}20`,
                      color: getStatusColor(z.level),
                      border: `1px solid ${getStatusColor(z.level)}`,
                    }}
                  >
                    {z.status}
                  </span>
                  <span className="text-[0.5rem] text-[#3a5565]">{z.incidents} events</span>
                </div>
              </button>
            ))}
        </div>
      </div>

      {/* Legend */}
      <div className="fixed bottom-12 left-80 z-[100] min-w-[165px] border border-[rgba(0,255,180,0.15)] bg-[rgba(0,255,180,0.04)] p-3.5 backdrop-blur-sm">
        <div className="mb-2.5 border-b border-[rgba(0,255,180,0.15)] pb-2 text-[0.5rem] tracking-[0.2em] opacity-40">THREAT INDEX</div>
        <div className="space-y-1.5 text-[0.6rem] tracking-[0.08em]">
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-[#ff2244] shadow-[0_0_7px_#ff2244]" />
            CRITICAL
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-[#ff8800] shadow-[0_0_7px_#ff8800]" />
            HIGH
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-[#ffdd00] shadow-[0_0_7px_#ffdd00]" />
            ELEVATED
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-[#00ffb4] shadow-[0_0_7px_#00ffb4]" />
            MONITORED
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-[#1a6655]" />
            STABLE
          </div>
        </div>
      </div>

      {/* Ticker */}
      <div className="fixed bottom-0 left-0 right-0 z-[100] flex h-7 items-center overflow-hidden border-t border-[rgba(255,34,68,0.3)] bg-[rgba(0,0,0,0.88)]">
        <div className="flex h-full shrink-0 items-center bg-[#ff2244] px-2.5 font-sans text-[0.48rem] font-bold tracking-[0.15em] text-black">INTEL FEED</div>
        <div className="animate-ticker whitespace-nowrap pl-5 text-[0.55rem] tracking-[0.06em] opacity-75">
          {tickerText}
          {"   ·   "}
          {tickerText}
        </div>
      </div>

      {/* Tooltip */}
      {hoveredZone && (
        <div
          className="pointer-events-none fixed z-[150] max-w-[280px] whitespace-nowrap border border-[rgba(0,255,180,0.15)] bg-[rgba(2,8,6,0.95)] px-3 py-1.5 text-[0.58rem] tracking-[0.09em] backdrop-blur-sm"
          style={{
            left: tooltipPos.x,
            top: tooltipPos.y,
            borderColor: getStatusColor(hoveredZone.level),
            color: getStatusColor(hoveredZone.level),
          }}
        >
          {hoveredZone.name} · {hoveredZone.status} · CLICK FOR INTEL
        </div>
      )}

      {/* Modal */}
      {isModalOpen && selectedZone && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-[rgba(0,0,0,0.55)] backdrop-blur-sm" onClick={closeModal}>
          <div className="flex max-h-[85vh] w-auto min-w-[320px] max-w-[90vw] flex-col overflow-hidden border border-[rgba(0,255,180,0.15)] bg-[rgba(2,9,7,0.98)]" onClick={(e) => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="flex shrink-0 items-start justify-between border-b border-[rgba(0,255,180,0.15)] px-5 pb-3 pt-4">
              <div>
                <div className="mb-1 font-sans text-sm tracking-[0.16em]" style={{ color: getStatusColor(selectedZone.level) }}>
                  {selectedZone.name}
                </div>
                <div className="text-[0.52rem] tracking-[0.14em] opacity-40">
                  {selectedZone.category} · {selectedZone.country}
                </div>
              </div>
              <button className="shrink-0 border border-[rgba(0,255,180,0.2)] px-2.5 py-1 text-[0.58rem] tracking-[0.1em] transition-all hover:border-[#ff2244] hover:bg-[rgba(255,34,68,0.15)] hover:text-[#ff2244]" onClick={closeModal}>
                ✕ CLOSE
              </button>
            </div>

            {/* Modal Stats */}
            <div className="grid shrink-0 grid-cols-3 border-b border-[rgba(0,255,180,0.15)]">
              <div className="flex flex-col gap-1 border-r border-[rgba(0,255,180,0.15)] px-4 py-3">
                <span className="text-[0.47rem] tracking-[0.18em] opacity-40">THREAT LEVEL</span>
                <span className="font-sans text-sm" style={{ color: getStatusColor(selectedZone.level) }}>
                  {selectedZone.status}
                </span>
              </div>
              <div className="flex flex-col gap-1 border-r border-[rgba(0,255,180,0.15)] px-4 py-3">
                <span className="text-[0.47rem] tracking-[0.18em] opacity-40">EVENTS (30D)</span>
                <span className="font-sans text-sm">{selectedZone.incidents}</span>
              </div>
              <div className="flex flex-col gap-1 px-4 py-3">
                <span className="text-[0.47rem] tracking-[0.18em] opacity-40">ALERT STATUS</span>
                <span className="font-sans text-sm">{selectedZone.level > 0.85 ? "IMMEDIATE" : selectedZone.level > 0.65 ? "ELEVATED" : "ACTIVE"}</span>
              </div>
            </div>

            {/* Threat Bar */}
            <div className="h-1 shrink-0 bg-[rgba(255,255,255,0.06)]">
              <div
                className="h-full transition-all duration-500"
                style={{
                  width: `${selectedZone.level * 100}%`,
                  background: getStatusColor(selectedZone.level),
                  boxShadow: `0 0 12px ${getStatusColor(selectedZone.level)}`,
                }}
              />
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto px-5 py-4">
              {isLoadingIntel ? (
                <div className="animate-pulse py-6 text-center text-sm tracking-[0.12em] opacity-45">QUERYING INTELLIGENCE FEED...</div>
              ) : modalIntel ? (
                <>
                  <div className="mb-2 border-b border-[rgba(0,255,180,0.07)] pb-1.5 text-[0.49rem] tracking-[0.22em] opacity-40">SITUATION REPORT</div>
                  <p className="mb-4 text-[0.67rem] leading-relaxed tracking-[0.035em] opacity-85">{modalIntel.summary}</p>

                  <div className="mb-2 border-b border-[rgba(0,255,180,0.07)] pb-1.5 text-[0.49rem] tracking-[0.22em] opacity-40">THREAT DRIVERS</div>
                  <div className="mb-4 flex flex-wrap gap-1.5">
                    {modalIntel.drivers.map((d, i) => (
                      <span key={i} className="border px-2 py-0.5 text-[0.5rem] tracking-[0.1em] opacity-80" style={{ borderColor: getStatusColor(selectedZone.level), color: getStatusColor(selectedZone.level) }}>
                        {d}
                      </span>
                    ))}
                  </div>

                  <div className="mb-2 border-b border-[rgba(0,255,180,0.07)] pb-1.5 text-[0.49rem] tracking-[0.22em] opacity-40">RECENT ACTIVITY</div>
                  <div className="mb-4 space-y-2">
                    {modalIntel.events.map((ev, i) => (
                      <div key={i} className="grid grid-cols-[8px_1fr_auto] items-start gap-x-2.5 border border-[rgba(0,255,180,0.07)] bg-[rgba(0,255,180,0.02)] p-2.5">
                        <div className="mt-0.5 h-2 w-2 rounded-full" style={{ background: getStatusColor(selectedZone.level), boxShadow: `0 0 5px ${getStatusColor(selectedZone.level)}` }} />
                        <div className="text-[0.62rem] leading-relaxed tracking-[0.03em] opacity-85">{ev.text}</div>
                        <div className="whitespace-nowrap text-[0.49rem] tracking-[0.08em] opacity-30">{ev.time}</div>
                      </div>
                    ))}
                  </div>

                  <div className="mb-2 border-b border-[rgba(0,255,180,0.07)] pb-1.5 text-[0.49rem] tracking-[0.22em] opacity-40">NEAR-TERM OUTLOOK</div>
                  <p className="mb-4 border-l-2 pl-2.5 text-[0.67rem] leading-relaxed tracking-[0.035em] opacity-75" style={{ borderColor: getStatusColor(selectedZone.level) }}>
                    {modalIntel.outlook}
                  </p>

                  <div className="mb-2 border-b border-[rgba(0,255,180,0.07)] pb-1.5 text-[0.49rem] tracking-[0.22em] opacity-40">RELATED ARTICLES</div>
                  <div className="space-y-2">
                    {modalIntel.articles.map((article, i) => (
                      <a
                        key={i}
                        href={article.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group block border border-[rgba(0,255,180,0.1)] bg-[rgba(0,255,180,0.02)] p-2.5 transition-all hover:border-[#00ffb4] hover:bg-[rgba(0,255,180,0.06)]"
                      >
                        <div className="mb-1 text-[0.65rem] leading-snug tracking-[0.02em] text-[#c8fff0] group-hover:text-[#00ffb4]">
                          {article.title}
                        </div>
                        <div className="flex items-center justify-between text-[0.5rem] tracking-[0.08em] opacity-50">
                          <span className="flex items-center gap-1.5">
                            <span className="inline-block h-1 w-1 rounded-full bg-[#00ffb4]" />
                            {article.source}
                          </span>
                          <span>{article.time}</span>
                        </div>
                      </a>
                    ))}
                  </div>
                </>
              ) : null}
            </div>

            {/* Modal Footer */}
            <div className="shrink-0 border-t border-[rgba(0,255,180,0.15)] px-5 py-2 text-right text-[0.46rem] tracking-[0.09em] opacity-25">SOURCE: AI INTELLIGENCE SYNTHESIS · REAL-TIME</div>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes ticker {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        .animate-ticker {
          animation: ticker 60s linear infinite;
        }
      `}</style>
    </div>
  )
}
